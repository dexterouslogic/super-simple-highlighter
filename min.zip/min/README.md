# Super Simple Highlighter

##What is it?
A Chrome extension for highlighting text, and automatically attempt to restore highlight on each page revisit.
##Installation
Use the prepackaged version in the [app store](https://chrome.google.com/webstore/detail/super-simple-highlighter/hhlhjgianpocpoppaiihmlpgcoehlhio).
##Donate
Donations can be made with [Paypal](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=TXVYJTNXQKPCY) or [Amazon Wishlist](http://www.amazon.co.uk/registry/wishlist/2JZNJ3B74GUUU)
##Licenses
###Highlighter Blue Icon
[Highlighter Blue Icon](http://www.iconarchive.com/show/soft-scraps-icons-by-hopstarter/Highlighter-Blue-icon.html) by [Hopstarter](http://hopstarter.deviantart.com) is licensed under [CC BY-NC-ND 3.0](http://creativecommons.org/licenses/by-nc-nd/3.0/)
###Exclamation Icon
[Exclamation Icon](https://www.iconfinder.com/icons/32453/alert_attention_danger_error_exclamation_hanger_message_problem_warning_icon) by [Aha-soft](http://www.aha-soft.com/) is licensed under [CC BY 3.0](http://creativecommons.org/licenses/by/3.0/)

    Super Simple Highlighter
    Copyright (C) 2015 einzelcode
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    
    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.